package controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import model.Emp;


	@Controller
	public class EmployeeController {
	 
		@RequestMapping("empload")
		public ModelAndView empload()
		{
		return new ModelAndView("empview", "command", new Emp());
		}
		
		@RequestMapping(value="emplogic",method=RequestMethod.POST)
	    public ModelAndView empLogic(@ModelAttribute("SpringMvcHibernate")Emp e)
	    {
			Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session ses = sf.openSession();
			Transaction tx = ses.beginTransaction();
			ses.save(e);
			tx.commit();
			ses.close();
			ModelAndView obj=new ModelAndView("empview","command",new Emp());

			obj.addObject("res", "Data Inserted Successfully ");

	    	return obj;
	    }
		
		
		@RequestMapping("showemp")
		public ModelAndView showEmp()
		{
			Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session ses = sf.openSession();
			Query q = ses.createQuery("from Emp e");
			List lst = q.list();
			ModelAndView obj = new ModelAndView("showemp","key", lst);
			return obj;
		}
		@RequestMapping("findemp")
	    public ModelAndView findEmp(HttpServletRequest request)
	    {
			Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session ses = sf.openSession();
			Query q = ses.createQuery("from Emp e where e.empid=?");
			q.setString(0,request.getParameter("q"));
			List lst = q.list();
			ModelAndView obj=new ModelAndView("findemp","key",lst);
	        return obj;
	    }
		@RequestMapping("updateemp")
		public ModelAndView updateEmp(HttpServletRequest request)
		{
	    Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tx = ses.beginTransaction();
		Object o = ses.get(Emp.class, Integer.parseInt(request.getParameter("txtempid")));
		Emp e  =(Emp)o;
		e.setEmpname(request.getParameter("txtempname"));
		e.setJob(request.getParameter("txtjob"));
		e.setSalary(Integer.parseInt(request.getParameter("txtsal")));
		ses.update(e);
		tx.commit();
		ses.close();
		ModelAndView obj = new ModelAndView("redirect:showemp.do");
		return obj;
	    }
		@RequestMapping("deleteemp")
	    public ModelAndView deleteEmp(HttpServletRequest request)
	    {
			Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session ses = sf.openSession();
			Transaction tx = ses.beginTransaction();
			Object o = ses.get(Emp.class,Integer.parseInt(request.getParameter("q")));
			Emp e = (Emp)o;
			ses.delete(e);
			tx.commit();
			ses.close();
			ModelAndView obj=new ModelAndView("redirect:showemp.do");
	        return obj;
	    }

}
